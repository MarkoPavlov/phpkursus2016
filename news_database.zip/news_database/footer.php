<p>
<i>Copyleft 2008-<?php echo date("Y"); ?></i>

</body>
</html>