<html>
<head>
<title>Uudiste haldamise s�steem</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>

<body>
<a href=insert.php>Sisestamine</a> | 
<a href=show.php>Vaatamine</a> | 
<a href=search.php>Otsing</a> | 
<br>

<?php

  include "functions.php";
  include "dbconnect.php";

  //$_POST = post_secure($_POST);
  //$_GET = get_secure($_GET);

?>