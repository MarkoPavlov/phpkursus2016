<?php

//# make post values secure
//function post_secure($_POST)
//{
//  #let's make strings secure
//  foreach($_POST as $key => $val)
//  {
//    $_POST[$key] = addslashes($_POST[$key]);
//  }
  
//  return $_POST;
//}

//# make get values secure
//function get_secure($_GET)
//{
//  #let's make strings secure
//  foreach($_GET as $key => $val)
//  {
//    $_GET[$key] = addslashes($_GET[$key]);
//  }
  
//  return $_GET;
//}

?>